//package com.dal;
//
//public interface IPrepositionDAO {
//
//}
