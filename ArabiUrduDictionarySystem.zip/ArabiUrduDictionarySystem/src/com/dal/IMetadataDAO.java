//package com.dal;
//
//public interface IMetadataDAO {
//
//}
