//package com.dal;
//
//public interface IExampleDAO {
//
//}
