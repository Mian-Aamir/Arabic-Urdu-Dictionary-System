package com.main;

import com.ui.CLI;

public class Main {
    public static void main(String[] args) {
        new CLI().start();
    }
}
