//package com.bll;
//
//public class ExampleBO {
//
//}
