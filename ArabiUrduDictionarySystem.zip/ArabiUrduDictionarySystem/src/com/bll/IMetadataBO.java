//package com.bll;
//
//public interface IMetadataBO {
//
//}
