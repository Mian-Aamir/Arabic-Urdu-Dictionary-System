//package com.bll;
//
//public interface IPrepositionBO {
//
//}
