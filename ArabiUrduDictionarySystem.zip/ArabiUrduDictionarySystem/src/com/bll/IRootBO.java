//package com.bll;
//
//import java.util.List;
//
//import com.dto.RootDTO;
//
//public interface IRootBO {
//	boolean addRoot(RootDTO root);
//
//	boolean updateRoot(RootDTO root);
//
//	boolean deleteRoot(String rootId);
//
//	RootDTO getRootById(String rootId);
//
//	List<RootDTO> getAllRoots();
//}
