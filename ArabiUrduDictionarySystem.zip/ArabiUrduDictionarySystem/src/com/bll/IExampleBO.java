//package com.bll;
//
//public interface IExampleBO {
//
//}
