//package com.bll;
//
//public class MetadataBO {
//
//}
