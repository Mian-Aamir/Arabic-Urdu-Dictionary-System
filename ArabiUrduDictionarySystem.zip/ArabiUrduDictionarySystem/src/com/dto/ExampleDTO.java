//package com.dto;
//
//public class ExampleDTO {
//    private int id;
//    private int wordId;
//    private String sentence;
//    private String source;
//    private String reference;
//
//    // Getters & Setters
//    public int getId() { return id; }
//    public void setId(int id) { this.id = id; }
//
//    public int getWordId() { return wordId; }
//    public void setWordId(int wordId) { this.wordId = wordId; }
//
//    public String getSentence() { return sentence; }
//    public void setSentence(String sentence) { this.sentence = sentence; }
//
//    public String getSource() { return source; }
//    public void setSource(String source) { this.source = source; }
//
//    public String getReference() { return reference; }
//    public void setReference(String reference) { this.reference = reference; }
//}
