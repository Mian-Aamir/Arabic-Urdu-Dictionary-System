//package com.dto;
//
//public class MetadataDTO {
//    private int id;
//    private int wordId;
//    private String gender;
//    private String number;
//    private String verbForm;
//    private String tense;
//    private String transitivity;
//
//    // Getters & Setters
//    public int getId() { return id; }
//    public void setId(int id) { this.id = id; }
//
//    public int getWordId() { return wordId; }
//    public void setWordId(int wordId) { this.wordId = wordId; }
//
//    public String getGender() { return gender; }
//    public void setGender(String gender) { this.gender = gender; }
//
//    public String getNumber() { return number; }
//    public void setNumber(String number) { this.number = number; }
//
//    public String getVerbForm() { return verbForm; }
//    public void setVerbForm(String verbForm) { this.verbForm = verbForm; }
//
//    public String getTense() { return tense; }
//    public void setTense(String tense) { this.tense = tense; }
//
//    public String getTransitivity() { return transitivity; }
//    public void setTransitivity(String transitivity) { this.transitivity = transitivity; }
//	
//}
