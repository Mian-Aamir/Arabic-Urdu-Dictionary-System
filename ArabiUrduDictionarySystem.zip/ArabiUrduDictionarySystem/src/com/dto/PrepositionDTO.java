//package com.dto;
//
//public class PrepositionDTO {
//    private int id;
//    private int wordId;
//    private String preposition;
//    private String urduMeaning;
//
//    // Getters & Setters
//    public int getId() { return id; }
//    public void setId(int id) { this.id = id; }
//
//    public int getWordId() { return wordId; }
//    public void setWordId(int wordId) { this.wordId = wordId; }
//
//    public String getPreposition() { return preposition; }
//    public void setPreposition(String preposition) { this.preposition = preposition; }
//
//    public String getUrduMeaning() { return urduMeaning; }
//    public void setUrduMeaning(String urduMeaning) { this.urduMeaning = urduMeaning; }
//}
